from setuptools import setup, find_packages

setup(
    name='gold33423324',
    version='0.0.1',
    packages=find_packages(),
    install_requires=[
        # Tambahkan dependensi jika diperlukan
    ],
)